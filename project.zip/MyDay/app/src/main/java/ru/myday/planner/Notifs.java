package ru.myday.planner;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Bundle;

/** Показ уведомлений с кнопками «Выполнено» и «Отложить». */
public final class Notifs {
    static final String CHANNEL = "reminders";

    private Notifs() {}

    public static void ensureChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Напоминания", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Напоминания о задачах, заметках, привычках и таймере");
        ch.enableVibration(true);
        ch.enableLights(true);
        nm.createNotificationChannel(ch);
    }

    private static PendingIntent action(Context c, String act, Bundle b, int nid) {
        Intent i = new Intent(c, ActionReceiver.class);
        i.setAction(act);
        i.putExtras(b);
        return PendingIntent.getBroadcast(c, nid, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void show(Context c, String kind, Bundle ex) {
        ensureChannel(c);
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;

        Bundle b = new Bundle(ex);
        b.putString("kind", kind);
        b.remove("orig");

        int nid = b.getInt("nid", 1);
        String id = b.getString("id", "");
        String title = b.getString("title", "Мой день");
        String text = b.getString("text", "");

        int accent = Store.color(Store.settings(Store.load(c)).optString("accent", "#7c5cff"), 0xFF7C5CFF);

        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("open", kind + ":" + id);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent content = PendingIntent.getActivity(c, nid, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder nb = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setColor(accent)
                .setAutoCancel(true)
                .setCategory("timer".equals(kind) ? Notification.CATEGORY_ALARM : Notification.CATEGORY_REMINDER)
                .setContentIntent(content);

        if ("task".equals(kind)) {
            nb.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_check),
                    "Выполнено", action(c, ActionReceiver.ACT_DONE, b, nid)).build());
        } else if ("habit".equals(kind)) {
            nb.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_check),
                    "Отметить", action(c, ActionReceiver.ACT_HABIT, b, nid)).build());
        }
        if (!"timer".equals(kind)) {
            nb.addAction(new Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_snooze),
                    "Отложить", action(c, ActionReceiver.ACT_SNOOZE, b, nid)).build());
        }
        try {
            nm.notify(nid, nb.build());
        } catch (SecurityException ignored) {
        }
    }
}
