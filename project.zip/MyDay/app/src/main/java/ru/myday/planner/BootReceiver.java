package ru.myday.planner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** После перезагрузки телефона или смены времени — заново ставим напоминания. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Reminders.rescheduleAll(c);
        Widgets.updateAll(c);
    }
}
