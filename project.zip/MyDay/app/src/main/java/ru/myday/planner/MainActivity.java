package ru.myday.planner;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_EXPORT = 11;
    private static final int REQ_IMPORT = 12;
    private static final int REQ_NOTIF = 13;

    static volatile MainActivity current;

    private WebView web;
    private boolean loaded = false;
    private String pendingOpen = null;
    private String exportBuf = null;

    /** Данные изменились снаружи (виджет, уведомление) — обновить экран. */
    static void dataChanged() {
        final MainActivity a = current;
        if (a != null) a.runOnUiThread(() -> a.js("window.reloadData&&window.reloadData()"));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Notifs.ensureChannel(this);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0F1115);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                loaded = true;
                js("window.sysDark&&window.sysDark(" + isNight() + ")");
                deliverOpen();
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");

        handleIntent(getIntent());
        Reminders.rescheduleAll(this);
        Widgets.updateAll(this);
    }

    private boolean isNight() {
        int m = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return m == Configuration.UI_MODE_NIGHT_YES;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (loaded) js("window.sysDark&&window.sysDark(" + isNight() + ")");
    }

    void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i == null) return;
        String o = i.getStringExtra("open");
        if (o != null) {
            pendingOpen = o;
            i.removeExtra("open");
            if (loaded) deliverOpen();
        }
    }

    private void deliverOpen() {
        if (pendingOpen == null) return;
        js("window.appOpen&&window.appOpen(" + JSONObject.quote(pendingOpen) + ")");
        pendingOpen = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        current = this;
        if (loaded) js("window.reloadData&&window.reloadData()");
    }

    @Override
    protected void onPause() {
        js("window.flush&&window.flush()");
        if (current == this) current = null;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (web == null || !loaded) {
            finish();
            return;
        }
        web.evaluateJavascript("(window.goBack&&window.goBack())?'1':'0'", v -> {
            if (v == null || !v.contains("1")) finish();
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (req == REQ_EXPORT && exportBuf != null) {
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out != null) out.write(exportBuf.getBytes(StandardCharsets.UTF_8));
                toast("Резервная копия сохранена");
            } catch (Exception e) {
                toast("Не удалось сохранить файл");
            }
            exportBuf = null;
        } else if (req == REQ_IMPORT) {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) return;
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                String text = new String(bo.toByteArray(), StandardCharsets.UTF_8);
                js("window.onImport&&window.onImport(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                toast("Не удалось прочитать файл");
            }
        }
    }

    private void toast(String t) {
        Toast.makeText(this, t, Toast.LENGTH_SHORT).show();
    }

    private boolean notifGranted() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            return false;
        NotificationManager nm = getSystemService(NotificationManager.class);
        return nm == null || nm.areNotificationsEnabled();
    }

    private void openSettingsScreen(String what) {
        String pkg = getPackageName();
        Intent i;
        if ("notif".equals(what)) {
            i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
        } else if ("alarm".equals(what) && Build.VERSION.SDK_INT >= 31) {
            i = new Intent("android.settings.REQUEST_SCHEDULE_EXACT_ALARM", Uri.parse("package:" + pkg));
        } else if ("battery".equals(what)) {
            i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
        } else {
            i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
        }
        try {
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg)));
            } catch (Exception ignored) {
            }
        }
    }

    /** Методы, доступные из JavaScript как window.Android.* */
    public class Bridge {
        @JavascriptInterface
        public String load() {
            return Store.loadRaw(MainActivity.this);
        }

        @JavascriptInterface
        public void save(String json) {
            Store.saveRaw(MainActivity.this, json);
            Reminders.rescheduleAll(MainActivity.this);
            Widgets.updateAll(MainActivity.this);
        }

        @JavascriptInterface
        public void exportData(String json, String name) {
            runOnUiThread(() -> {
                exportBuf = json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_EXPORT);
                } catch (Exception e) {
                    toast("Не удалось открыть окно сохранения");
                }
            });
        }

        @JavascriptInterface
        public void importData() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(i, REQ_IMPORT);
                } catch (Exception e) {
                    toast("Не удалось открыть выбор файла");
                }
            });
        }

        @JavascriptInterface
        public void share(String text) {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                try {
                    startActivity(Intent.createChooser(i, "Поделиться"));
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void toast(String t) {
            runOnUiThread(() -> MainActivity.this.toast(t));
        }

        @JavascriptInterface
        public void haptic() {
            runOnUiThread(() -> {
                if (web != null) web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            });
        }

        @JavascriptInterface
        public void setBars(String color, boolean light) {
            runOnUiThread(() -> {
                try {
                    int c = Color.parseColor(color);
                    Window w = getWindow();
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    if (web != null) web.setBackgroundColor(c);
                    View d = w.getDecorView();
                    int f = d.getSystemUiVisibility();
                    int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    if (light) f |= flags;
                    else f &= ~flags;
                    d.setSystemUiVisibility(f);
                } catch (Exception ignored) {
                }
            });
        }

        @JavascriptInterface
        public void openSettings(String what) {
            runOnUiThread(() -> openSettingsScreen(what));
        }

        @JavascriptInterface
        public void requestNotif() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, REQ_NOTIF);
                } else if (!notifGranted()) {
                    openSettingsScreen("notif");
                }
            });
        }

        @JavascriptInterface
        public String info() {
            JSONObject o = new JSONObject();
            try {
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("notif", notifGranted());
                boolean exact = true;
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
                    exact = am != null && am.canScheduleExactAlarms();
                }
                o.put("exact", exact);
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                o.put("battery", pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()));
                o.put("dark", isNight());
                o.put("version", "1.0");
            } catch (Exception ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void startTimer(int seconds, String title, String text) {
            Reminders.timer(MainActivity.this, seconds, title, text);
        }

        @JavascriptInterface
        public void cancelTimer() {
            Reminders.cancelTimer(MainActivity.this);
        }

        @JavascriptInterface
        public void testNotify() {
            Reminders.test(MainActivity.this);
        }
    }
}
