package ru.myday.planner;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

import org.json.JSONObject;

/** Виджет «Задачи на сегодня». Нажатие на задачу — отметить выполненной. */
public class DayWidget extends AppWidgetProvider {
    static final String ACT_TOGGLE = "ru.myday.planner.WIDGET_TOGGLE";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        Widgets.render(c, m, ids, false);
        m.notifyAppWidgetViewDataChanged(ids, R.id.w_list);
    }

    @Override
    public void onReceive(Context c, Intent i) {
        super.onReceive(c, i);
        if (!ACT_TOGGLE.equals(i.getAction())) return;
        String id = i.getStringExtra("id");
        String date = i.getStringExtra("date");
        if (id == null) return;
        if (date == null || date.isEmpty()) date = Store.todayKey();
        JSONObject data = Store.load(c);
        JSONObject t = Store.find(data.optJSONArray("tasks"), id);
        if (t == null) return;
        Store.setDone(t, date, !Store.isDone(t, date));
        Store.save(c, data);
        Widgets.updateAll(c);
        Reminders.rescheduleAll(c);
        MainActivity.dataChanged();
    }
}
