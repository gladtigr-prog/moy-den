package ru.myday.planner;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Общий код для двух виджетов: «Задачи на сегодня» и «Заметки». */
public final class Widgets {
    private Widgets() {}

    static final int[] TITLE = {0xFFF2F3F7, 0xFF15171C, 0xFFFFFFFF};
    static final int[] SUB = {0xFF9AA0AE, 0xFF6B7280, 0xDDFFFFFF};

    static int styleIndex(JSONObject settings) {
        String s = settings.optString("wStyle", "dark");
        if ("light".equals(s)) return 1;
        if ("trans".equals(s)) return 2;
        return 0;
    }

    static int bgRes(int style) {
        if (style == 1) return R.drawable.wbg_light;
        if (style == 2) return R.drawable.wbg_trans;
        return R.drawable.wbg_dark;
    }

    public static void updateAll(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        if (m == null) return;
        int[] a = m.getAppWidgetIds(new ComponentName(c, DayWidget.class));
        if (a != null && a.length > 0) {
            render(c, m, a, false);
            m.notifyAppWidgetViewDataChanged(a, R.id.w_list);
        }
        int[] b = m.getAppWidgetIds(new ComponentName(c, NotesWidget.class));
        if (b != null && b.length > 0) {
            render(c, m, b, true);
            m.notifyAppWidgetViewDataChanged(b, R.id.w_list);
        }
    }

    private static PendingIntent openApp(Context c, String open, int req) {
        Intent i = new Intent(c, MainActivity.class);
        if (open != null) i.putExtra("open", open);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(c, req, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static int mutable() {
        return Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0;
    }

    public static void render(Context c, AppWidgetManager m, int[] ids, boolean notes) {
        JSONObject data = Store.load(c);
        JSONObject st = Store.settings(data);
        int style = styleIndex(st);
        int accent = Store.color(st.optString("accent", "#7c5cff"), 0xFF7C5CFF);

        String title, date, count, empty;
        int max = 1, prog = 0;
        if (notes) {
            List<Store.Item> items = Store.widgetNotes(data);
            title = "Заметки";
            date = items.isEmpty() ? "Пока пусто" : "Всего: " + items.size();
            count = "";
            empty = "Нет заметок.\nНажмите +, чтобы создать";
        } else {
            List<Store.Item> items = Store.widgetDay(data, true);
            int done = 0;
            for (Store.Item it : items) if (it.done) done++;
            title = "Сегодня";
            String d = new SimpleDateFormat("EEEE, d MMMM", new Locale("ru")).format(new Date());
            date = d.isEmpty() ? d : Character.toUpperCase(d.charAt(0)) + d.substring(1);
            count = items.isEmpty() ? "" : done + " из " + items.size();
            max = Math.max(1, items.size());
            prog = done;
            empty = "На сегодня задач нет.\nНажмите +, чтобы добавить";
        }

        for (int id : ids) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_day);
            rv.setInt(R.id.w_root, "setBackgroundResource", bgRes(style));
            rv.setTextViewText(R.id.w_title, title);
            rv.setTextColor(R.id.w_title, TITLE[style]);
            rv.setTextViewText(R.id.w_date, date);
            rv.setTextColor(R.id.w_date, SUB[style]);
            rv.setTextViewText(R.id.w_count, count);
            rv.setTextColor(R.id.w_count, SUB[style]);
            rv.setTextViewText(R.id.w_empty, empty);
            rv.setTextColor(R.id.w_empty, SUB[style]);
            rv.setInt(R.id.w_add, "setColorFilter", accent);

            if (notes) {
                rv.setViewVisibility(R.id.w_progress, View.GONE);
            } else {
                rv.setViewVisibility(R.id.w_progress, View.VISIBLE);
                rv.setProgressBar(R.id.w_progress, max, prog, false);
            }

            Intent svc = new Intent(c, WidgetService.class);
            svc.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
            svc.putExtra("mode", notes ? "notes" : "day");
            svc.setData(Uri.parse("myday://widget/" + (notes ? "notes" : "day") + "/" + id));
            rv.setRemoteAdapter(R.id.w_list, svc);
            rv.setEmptyView(R.id.w_list, R.id.w_empty);

            if (notes) {
                rv.setOnClickPendingIntent(R.id.w_header, openApp(c, "tab:notes", 203));
                rv.setOnClickPendingIntent(R.id.w_add, openApp(c, "newnote", 204));
                rv.setOnClickPendingIntent(R.id.w_empty, openApp(c, "newnote", 205));
                Intent tpl = new Intent(c, MainActivity.class);
                tpl.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                rv.setPendingIntentTemplate(R.id.w_list, PendingIntent.getActivity(c, 206, tpl,
                        PendingIntent.FLAG_UPDATE_CURRENT | mutable()));
            } else {
                rv.setOnClickPendingIntent(R.id.w_header, openApp(c, "tab:today", 201));
                rv.setOnClickPendingIntent(R.id.w_add, openApp(c, "quickadd", 202));
                rv.setOnClickPendingIntent(R.id.w_empty, openApp(c, "quickadd", 207));
                Intent tpl = new Intent(c, DayWidget.class);
                tpl.setAction(DayWidget.ACT_TOGGLE);
                rv.setPendingIntentTemplate(R.id.w_list, PendingIntent.getBroadcast(c, 208, tpl,
                        PendingIntent.FLAG_UPDATE_CURRENT | mutable()));
            }
            m.updateAppWidget(id, rv);
        }
    }
}
