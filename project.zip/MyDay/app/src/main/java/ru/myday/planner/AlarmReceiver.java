package ru.myday.planner;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import org.json.JSONObject;

/** Срабатывание будильника: показать уведомление и запланировать следующее. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        Bundle ex = i.getExtras();
        if (ex == null) ex = new Bundle();
        String kind = ex.getString("kind", "");

        if ("midnight".equals(kind)) {
            Reminders.rescheduleAll(c);
            Widgets.updateAll(c);
            MainActivity.dataChanged();
            return;
        }
        if ("snooze".equals(kind)) kind = ex.getString("orig", "task");

        String id = ex.getString("id", "");
        String date = ex.getString("date", "");

        // Проверяем, не выполнена ли уже задача/привычка
        if ("task".equals(kind) || "habit".equals(kind)) {
            JSONObject data = Store.load(c);
            if ("task".equals(kind)) {
                JSONObject t = Store.find(data.optJSONArray("tasks"), id);
                if (t == null || (!date.isEmpty() && Store.isDone(t, date))) {
                    Reminders.rescheduleAll(c);
                    return;
                }
            } else {
                JSONObject h = Store.find(data.optJSONArray("habits"), id);
                if (h == null || Store.hasStr(h.optJSONArray("done"), date)) {
                    Reminders.rescheduleAll(c);
                    return;
                }
            }
        } else if ("note".equals(kind)) {
            JSONObject n = Store.find(Store.load(c).optJSONArray("notes"), id);
            if (n == null || n.optBoolean("trashed", false)) return;
        }

        Notifs.show(c, kind, ex);
        if (!"timer".equals(kind)) Reminders.rescheduleAll(c);
    }
}
