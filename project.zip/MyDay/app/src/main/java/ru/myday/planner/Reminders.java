package ru.myday.planner;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Планирование всех напоминаний через AlarmManager. */
public final class Reminders {
    static final String PREFS = "myday";
    static final String KEY_CODES = "alarm_codes";
    static final String ACTION = "ru.myday.planner.ALARM";
    static final int CODE_MIDNIGHT = 7;
    static final int CODE_TIMER = 8;
    static final int CODE_TEST = 9;

    private Reminders() {}

    public static int code(String s) {
        int c = s.hashCode() & 0x7fffffff;
        return c < 100 ? c + 100 : c;
    }

    private static PendingIntent pending(Context c, int code, Bundle extras, int flag) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(ACTION);
        i.setData(Uri.parse("myday://alarm/" + code));
        if (extras != null) i.putExtras(extras);
        return PendingIntent.getBroadcast(c, code, i, flag | PendingIntent.FLAG_IMMUTABLE);
    }

    public static void schedule(Context c, int code, long when, Bundle extras) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pending(c, code, extras, PendingIntent.FLAG_UPDATE_CURRENT);
        boolean exact = true;
        if (Build.VERSION.SDK_INT >= 31) exact = am.canScheduleExactAlarms();
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        } catch (SecurityException e) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    public static void cancel(Context c, int code) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = pending(c, code, null, PendingIntent.FLAG_NO_CREATE);
        if (pi != null) {
            if (am != null) am.cancel(pi);
            pi.cancel();
        }
    }

    private static String whenLabel(String dayKey, String time) {
        String today = Store.todayKey();
        Calendar t = Store.parse(today);
        t.add(Calendar.DAY_OF_MONTH, 1);
        String tomorrow = Store.key(t);
        if (dayKey.equals(today)) return "Сегодня в " + time;
        if (dayKey.equals(tomorrow)) return "Завтра в " + time;
        return Store.shortDate(dayKey) + " в " + time;
    }

    /** Пересчитать и поставить все напоминания заново. */
    public static synchronized void rescheduleAll(Context c) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> old = new HashSet<>(p.getStringSet(KEY_CODES, new HashSet<>()));
        Set<String> now = new HashSet<>();
        JSONObject data = Store.load(c);
        long nowMs = System.currentTimeMillis();

        // --- задачи ---
        JSONArray tasks = data.optJSONArray("tasks");
        if (tasks != null) for (int i = 0; i < tasks.length(); i++) {
            JSONObject t = tasks.optJSONObject(i);
            if (t == null) continue;
            int rem = t.optInt("remind", -1);
            String time = t.optString("time", "");
            String date = t.optString("date", "");
            int[] hm = Store.hm(time);
            if (rem < 0 || hm == null || date.isEmpty()) continue;

            String occKey = null;
            long when = 0;
            if (!Store.isRepeating(t)) {
                if (!t.optBoolean("done", false)) {
                    Calendar w = Store.parse(date);
                    w.set(Calendar.HOUR_OF_DAY, hm[0]);
                    w.set(Calendar.MINUTE, hm[1]);
                    w.add(Calendar.MINUTE, -rem);
                    if (w.getTimeInMillis() > nowMs) {
                        when = w.getTimeInMillis();
                        occKey = date;
                    }
                }
            } else {
                Calendar day = Store.todayMidnight();
                day.add(Calendar.DAY_OF_MONTH, -1);
                Calendar start = Store.parse(date);
                if (start.after(day)) day = start;
                for (int k = 0; k < 800; k++) {
                    String dk = Store.key(day);
                    if (Store.occursOn(t, dk) && !Store.isDone(t, dk)) {
                        Calendar w = (Calendar) day.clone();
                        w.set(Calendar.HOUR_OF_DAY, hm[0]);
                        w.set(Calendar.MINUTE, hm[1]);
                        w.add(Calendar.MINUTE, -rem);
                        if (w.getTimeInMillis() > nowMs) {
                            when = w.getTimeInMillis();
                            occKey = dk;
                            break;
                        }
                    }
                    JSONObject r = t.optJSONObject("repeat");
                    String until = r == null ? "" : r.optString("until", "");
                    if (!until.isEmpty() && dk.compareTo(until) > 0) break;
                    day.add(Calendar.DAY_OF_MONTH, 1);
                }
            }
            if (when > 0) {
                String id = t.optString("id");
                int code = code("t" + id);
                Bundle b = new Bundle();
                b.putString("kind", "task");
                b.putString("id", id);
                b.putString("date", occKey);
                b.putInt("nid", code);
                b.putString("title", t.optString("title", "Задача"));
                String notes = t.optString("notes", "").trim();
                if (notes.length() > 140) notes = notes.substring(0, 140) + "…";
                b.putString("text", whenLabel(occKey, time) + (notes.isEmpty() ? "" : "\n" + notes));
                schedule(c, code, when, b);
                now.add(String.valueOf(code));
            }
        }

        // --- заметки ---
        JSONArray notes = data.optJSONArray("notes");
        if (notes != null) {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            for (int i = 0; i < notes.length(); i++) {
                JSONObject n = notes.optJSONObject(i);
                if (n == null || n.optBoolean("trashed", false)) continue;
                String r = n.optString("remind", "");
                if (r.length() < 16) continue;
                try {
                    Date d = f.parse(r);
                    if (d == null || d.getTime() <= nowMs) continue;
                    String id = n.optString("id");
                    int code = code("n" + id);
                    Bundle b = new Bundle();
                    b.putString("kind", "note");
                    b.putString("id", id);
                    b.putInt("nid", code);
                    String title = n.optString("title", "").trim();
                    b.putString("title", title.isEmpty() ? "Напоминание" : title);
                    String body = n.optString("body", "").trim();
                    if (body.length() > 160) body = body.substring(0, 160) + "…";
                    b.putString("text", body.isEmpty() ? "Заметка" : body);
                    schedule(c, code, d.getTime(), b);
                    now.add(String.valueOf(code));
                } catch (Exception ignored) {
                }
            }
        }

        // --- привычки ---
        JSONArray habits = data.optJSONArray("habits");
        if (habits != null) for (int i = 0; i < habits.length(); i++) {
            JSONObject h = habits.optJSONObject(i);
            if (h == null) continue;
            int[] hm = Store.hm(h.optString("remind", ""));
            if (hm == null) continue;
            JSONArray days = h.optJSONArray("days");
            boolean all = days == null || days.length() == 0;
            JSONArray done = h.optJSONArray("done");
            Calendar day = Store.todayMidnight();
            for (int k = 0; k < 8; k++) {
                String dk = Store.key(day);
                if ((all || Store.hasInt(days, Store.iso(day))) && !Store.hasStr(done, dk)) {
                    Calendar w = (Calendar) day.clone();
                    w.set(Calendar.HOUR_OF_DAY, hm[0]);
                    w.set(Calendar.MINUTE, hm[1]);
                    if (w.getTimeInMillis() > nowMs) {
                        String id = h.optString("id");
                        int code = code("h" + id);
                        Bundle b = new Bundle();
                        b.putString("kind", "habit");
                        b.putString("id", id);
                        b.putString("date", dk);
                        b.putInt("nid", code);
                        b.putString("title", h.optString("name", "Привычка"));
                        b.putString("text", "Время для привычки — отметьте, когда сделаете");
                        schedule(c, code, w.getTimeInMillis(), b);
                        now.add(String.valueOf(code));
                        break;
                    }
                }
                day.add(Calendar.DAY_OF_MONTH, 1);
            }
        }

        for (String s : old) {
            if (!now.contains(s)) {
                try {
                    cancel(c, Integer.parseInt(s));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        p.edit().putStringSet(KEY_CODES, now).apply();
        scheduleMidnight(c);
    }

    /** Будильник на полночь — обновить виджет и повторы. */
    public static void scheduleMidnight(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Calendar m = Store.todayMidnight();
        m.add(Calendar.DAY_OF_MONTH, 1);
        m.add(Calendar.SECOND, 5);
        Bundle b = new Bundle();
        b.putString("kind", "midnight");
        PendingIntent pi = pending(c, CODE_MIDNIGHT, b, PendingIntent.FLAG_UPDATE_CURRENT);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, m.getTimeInMillis(), pi);
    }

    public static void snooze(Context c, Bundle ex, int minutes) {
        Bundle b = new Bundle(ex);
        String kind = ex.getString("kind", "task");
        b.putString("orig", kind);
        b.putString("kind", "snooze");
        int nid = ex.getInt("nid", 1);
        schedule(c, code("s" + nid), System.currentTimeMillis() + minutes * 60_000L, b);
    }

    public static void timer(Context c, int seconds, String title, String text) {
        Bundle b = new Bundle();
        b.putString("kind", "timer");
        b.putString("id", "");
        b.putInt("nid", CODE_TIMER);
        b.putString("title", title);
        b.putString("text", text);
        schedule(c, CODE_TIMER, System.currentTimeMillis() + Math.max(1, seconds) * 1000L, b);
    }

    public static void cancelTimer(Context c) {
        cancel(c, CODE_TIMER);
    }

    public static void test(Context c) {
        Bundle b = new Bundle();
        b.putString("kind", "timer");
        b.putString("id", "");
        b.putInt("nid", CODE_TEST);
        b.putString("title", "Проверка напоминаний");
        b.putString("text", "Всё работает! Так будут выглядеть ваши напоминания.");
        schedule(c, CODE_TEST, System.currentTimeMillis() + 5000L, b);
    }
}
