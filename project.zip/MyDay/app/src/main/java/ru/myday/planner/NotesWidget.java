package ru.myday.planner;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

/** Виджет «Заметки». Нажатие на заметку — открыть её в приложении. */
public class NotesWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        Widgets.render(c, m, ids, true);
        m.notifyAppWidgetViewDataChanged(ids, R.id.w_list);
    }
}
