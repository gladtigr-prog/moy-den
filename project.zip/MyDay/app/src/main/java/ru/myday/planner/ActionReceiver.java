package ru.myday.planner;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

/** Кнопки в уведомлении: «Выполнено», «Отметить», «Отложить». */
public class ActionReceiver extends BroadcastReceiver {
    static final String ACT_DONE = "ru.myday.planner.DONE";
    static final String ACT_HABIT = "ru.myday.planner.HABIT";
    static final String ACT_SNOOZE = "ru.myday.planner.SNOOZE";

    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        Bundle ex = i.getExtras();
        if (a == null || ex == null) return;

        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(ex.getInt("nid", 0));

        String id = ex.getString("id", "");
        String date = ex.getString("date", "");
        JSONObject data = Store.load(c);

        if (ACT_SNOOZE.equals(a)) {
            int min = Store.settings(data).optInt("snooze", 10);
            if (min <= 0) min = 10;
            Reminders.snooze(c, ex, min);
            return;
        }

        boolean changed = false;
        if (ACT_DONE.equals(a)) {
            JSONObject t = Store.find(data.optJSONArray("tasks"), id);
            if (t != null) {
                if (date.isEmpty()) date = Store.todayKey();
                Store.setDone(t, date, true);
                changed = true;
            }
        } else if (ACT_HABIT.equals(a)) {
            JSONObject h = Store.find(data.optJSONArray("habits"), id);
            if (h != null) {
                if (date.isEmpty()) date = Store.todayKey();
                JSONArray done = h.optJSONArray("done");
                if (done == null) {
                    done = new JSONArray();
                    try {
                        h.put("done", done);
                    } catch (Exception ignored) {
                    }
                }
                if (!Store.hasStr(done, date)) done.put(date);
                changed = true;
            }
        }
        if (changed) {
            Store.save(c, data);
            Reminders.rescheduleAll(c);
            Widgets.updateAll(c);
            MainActivity.dataChanged();
        }
    }
}
