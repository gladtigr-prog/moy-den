package ru.myday.planner;

import android.content.Context;
import android.content.Intent;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.StrikethroughSpan;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Строки списка в виджетах. */
public class WidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new Factory(getApplicationContext(), "notes".equals(intent.getStringExtra("mode")));
    }

    static final class Factory implements RemoteViewsFactory {
        private final Context c;
        private final boolean notes;
        private List<Store.Item> items = new ArrayList<>();
        private int titleColor = 0xFFF2F3F7, subColor = 0xFF9AA0AE, accent = 0xFF7C5CFF;

        private static final int[] PRIO = {0xFF8A90A0, 0xFF3B82F6, 0xFFF97316, 0xFFEF4444};

        Factory(Context c, boolean notes) {
            this.c = c;
            this.notes = notes;
        }

        @Override
        public void onCreate() {}

        @Override
        public void onDataSetChanged() {
            JSONObject data = Store.load(c);
            JSONObject st = Store.settings(data);
            int style = Widgets.styleIndex(st);
            titleColor = Widgets.TITLE[style];
            subColor = Widgets.SUB[style];
            accent = Store.color(st.optString("accent", "#7c5cff"), 0xFF7C5CFF);
            items = notes ? Store.widgetNotes(data) : Store.widgetDay(data, st.optBoolean("wDone", true));
        }

        @Override
        public void onDestroy() {
            items.clear();
        }

        @Override
        public int getCount() {
            return items.size();
        }

        @Override
        public RemoteViews getViewAt(int pos) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_item);
            if (pos < 0 || pos >= items.size()) return rv;
            Store.Item it = items.get(pos);

            CharSequence title = it.title;
            if (it.done) {
                SpannableString ss = new SpannableString(it.title);
                ss.setSpan(new StrikethroughSpan(), 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                title = ss;
            }
            rv.setTextViewText(R.id.it_title, title);
            rv.setTextColor(R.id.it_title, it.done ? subColor : titleColor);
            rv.setTextViewText(R.id.it_sub, it.sub);
            rv.setTextColor(R.id.it_sub, it.sub.startsWith("Просрочено") ? 0xFFEF4444 : subColor);
            rv.setViewVisibility(R.id.it_sub, it.sub.isEmpty() ? View.GONE : View.VISIBLE);

            if (notes) {
                rv.setViewVisibility(R.id.it_check, View.GONE);
            } else {
                rv.setViewVisibility(R.id.it_check, View.VISIBLE);
                rv.setImageViewResource(R.id.it_check, it.done ? R.drawable.ic_w_check_on : R.drawable.ic_w_check_off);
                int p = Math.max(0, Math.min(3, it.prio));
                rv.setInt(R.id.it_check, "setColorFilter", it.done ? accent : PRIO[p]);
            }

            if (it.color != 0) {
                rv.setViewVisibility(R.id.it_dot, View.VISIBLE);
                rv.setInt(R.id.it_dot, "setColorFilter", it.color);
            } else {
                rv.setViewVisibility(R.id.it_dot, View.GONE);
            }

            Intent fill = new Intent();
            fill.putExtra("id", it.id);
            fill.putExtra("date", it.date);
            if (notes) fill.putExtra("open", "note:" + it.id);
            rv.setOnClickFillInIntent(R.id.it_root, fill);
            return rv;
        }

        @Override
        public RemoteViews getLoadingView() {
            return null;
        }

        @Override
        public int getViewTypeCount() {
            return 1;
        }

        @Override
        public long getItemId(int pos) {
            return pos;
        }

        @Override
        public boolean hasStableIds() {
            return false;
        }
    }
}
