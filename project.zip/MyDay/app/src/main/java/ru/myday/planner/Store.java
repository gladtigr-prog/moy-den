package ru.myday.planner;

import android.content.Context;
import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Хранение всех данных приложения в одном JSON-файле + общая логика задач. */
public final class Store {
    private static final String FILE = "data.json";
    private static final Object LOCK = new Object();

    private Store() {}

    // ---------- файл ----------

    public static String loadRaw(Context c) {
        synchronized (LOCK) {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return "";
            try (FileInputStream in = new FileInputStream(f)) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return new String(bo.toByteArray(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                return "";
            }
        }
    }

    public static void saveRaw(Context c, String s) {
        if (s == null) return;
        synchronized (LOCK) {
            byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
            File tmp = new File(c.getFilesDir(), FILE + ".tmp");
            File f = new File(c.getFilesDir(), FILE);
            try (FileOutputStream out = new FileOutputStream(tmp)) {
                out.write(bytes);
                out.getFD().sync();
            } catch (IOException e) {
                return;
            }
            if (!tmp.renameTo(f)) {
                try (FileOutputStream out = new FileOutputStream(f)) {
                    out.write(bytes);
                } catch (IOException ignored) {
                }
            }
        }
    }

    public static JSONObject load(Context c) {
        String s = loadRaw(c);
        if (s.isEmpty()) return new JSONObject();
        try {
            return new JSONObject(s);
        } catch (JSONException e) {
            return new JSONObject();
        }
    }

    public static void save(Context c, JSONObject o) {
        saveRaw(c, o.toString());
    }

    public static JSONObject settings(JSONObject data) {
        JSONObject s = data.optJSONObject("settings");
        return s == null ? new JSONObject() : s;
    }

    // ---------- даты ----------

    public static String key(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    public static Calendar parse(String k) {
        Calendar c = Calendar.getInstance();
        c.clear();
        try {
            String[] p = k.split("-");
            c.set(Integer.parseInt(p[0]), Integer.parseInt(p[1]) - 1, Integer.parseInt(p[2]), 0, 0, 0);
        } catch (Exception ignored) {
        }
        return c;
    }

    public static Calendar todayMidnight() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    public static String todayKey() {
        return key(Calendar.getInstance());
    }

    /** 1 = понедельник ... 7 = воскресенье */
    public static int iso(Calendar c) {
        return (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 + 1;
    }

    public static int[] hm(String t) {
        try {
            String[] p = t.split(":");
            return new int[]{Integer.parseInt(p[0].trim()), Integer.parseInt(p[1].trim())};
        } catch (Exception e) {
            return null;
        }
    }

    public static int color(String hex, int def) {
        if (hex == null || hex.isEmpty() || "null".equals(hex)) return def;
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return def;
        }
    }

    // ---------- задачи ----------

    public static boolean isRepeating(JSONObject t) {
        JSONObject r = t.optJSONObject("repeat");
        return r != null && !"none".equals(r.optString("type", "none"));
    }

    public static boolean hasInt(JSONArray a, int v) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (a.optInt(i, -999) == v) return true;
        return false;
    }

    public static boolean hasStr(JSONArray a, String v) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (v.equals(a.optString(i))) return true;
        return false;
    }

    public static boolean occursOn(JSONObject t, String dayKey) {
        String date = t.optString("date", "");
        if (date.isEmpty()) return false;
        JSONObject r = t.optJSONObject("repeat");
        String type = r == null ? "none" : r.optString("type", "none");
        if ("none".equals(type)) return date.equals(dayKey);
        if (dayKey.compareTo(date) < 0) return false;
        String until = r.optString("until", "");
        if (!until.isEmpty() && dayKey.compareTo(until) > 0) return false;
        Calendar day = parse(dayKey);
        Calendar start = parse(date);
        int iso = iso(day);
        switch (type) {
            case "daily":
                return true;
            case "weekdays":
                return iso <= 5;
            case "weekly":
                return iso == iso(start);
            case "monthly":
                return day.get(Calendar.DAY_OF_MONTH) == start.get(Calendar.DAY_OF_MONTH);
            case "yearly":
                return day.get(Calendar.DAY_OF_MONTH) == start.get(Calendar.DAY_OF_MONTH)
                        && day.get(Calendar.MONTH) == start.get(Calendar.MONTH);
            case "custom":
                return hasInt(r.optJSONArray("days"), iso);
            default:
                return false;
        }
    }

    public static boolean isDone(JSONObject t, String dayKey) {
        if (isRepeating(t)) return hasStr(t.optJSONArray("doneDates"), dayKey);
        return t.optBoolean("done", false);
    }

    public static void setDone(JSONObject t, String dayKey, boolean v) {
        try {
            if (isRepeating(t)) {
                JSONArray a = t.optJSONArray("doneDates");
                if (a == null) a = new JSONArray();
                JSONArray out = new JSONArray();
                for (int i = 0; i < a.length(); i++) {
                    String s = a.optString(i);
                    if (!s.equals(dayKey)) out.put(s);
                }
                if (v) out.put(dayKey);
                t.put("doneDates", out);
            } else {
                t.put("done", v);
                t.put("doneAt", v ? todayKey() : "");
            }
        } catch (JSONException ignored) {
        }
    }

    public static JSONObject find(JSONArray arr, String id) {
        if (arr == null || id == null) return null;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }

    // ---------- элементы для виджетов ----------

    public static final class Item {
        public String id = "", date = "", title = "", sub = "";
        public boolean done;
        public int color;
        public int prio;
        String sortTime = "";
    }

    private static final String[] MONTHS_SHORT = {"янв", "фев", "мар", "апр", "мая", "июн",
            "июл", "авг", "сен", "окт", "ноя", "дек"};

    public static String shortDate(String k) {
        Calendar c = parse(k);
        return c.get(Calendar.DAY_OF_MONTH) + " " + MONTHS_SHORT[c.get(Calendar.MONTH)];
    }

    public static List<Item> widgetDay(JSONObject data, boolean showDone) {
        List<Item> out = new ArrayList<>();
        JSONArray tasks = data.optJSONArray("tasks");
        if (tasks == null) return out;
        Map<String, JSONObject> cats = new HashMap<>();
        JSONArray ca = data.optJSONArray("cats");
        if (ca != null) for (int i = 0; i < ca.length(); i++) {
            JSONObject c = ca.optJSONObject(i);
            if (c != null) cats.put(c.optString("id"), c);
        }
        String today = todayKey();
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject t = tasks.optJSONObject(i);
            if (t == null) continue;
            String date = t.optString("date", "");
            boolean overdue = !isRepeating(t) && !date.isEmpty() && date.compareTo(today) < 0
                    && !t.optBoolean("done", false);
            boolean todays = occursOn(t, today);
            if (!overdue && !todays) continue;
            String dk = overdue ? date : today;
            boolean done = isDone(t, dk);
            if (done && !showDone) continue;
            Item it = new Item();
            it.id = t.optString("id");
            it.date = dk;
            it.title = t.optString("title", "");
            it.done = done;
            it.prio = t.optInt("prio", 0);
            String time = t.optString("time", "");
            it.sortTime = overdue ? "00:00" : (time.isEmpty() ? "99:99" : time);
            StringBuilder sb = new StringBuilder();
            if (overdue) sb.append("Просрочено · ").append(shortDate(date));
            if (!time.isEmpty()) {
                if (sb.length() > 0) sb.append(" · ");
                sb.append(time);
            }
            JSONObject cat = cats.get(t.optString("cat", ""));
            if (cat != null) {
                if (sb.length() > 0) sb.append(" · ");
                sb.append(cat.optString("name", ""));
                it.color = color(cat.optString("color", ""), 0);
            }
            JSONArray subs = t.optJSONArray("subs");
            if (subs != null && subs.length() > 0) {
                int d = 0;
                for (int j = 0; j < subs.length(); j++) {
                    JSONObject s = subs.optJSONObject(j);
                    if (s != null && s.optBoolean("d", false)) d++;
                }
                if (sb.length() > 0) sb.append(" · ");
                sb.append(d).append("/").append(subs.length());
            }
            it.sub = sb.toString();
            out.add(it);
        }
        Collections.sort(out, (a, b) -> {
            if (a.done != b.done) return a.done ? 1 : -1;
            int c = a.sortTime.compareTo(b.sortTime);
            if (c != 0) return c;
            return b.prio - a.prio;
        });
        return out;
    }

    public static List<Item> widgetNotes(JSONObject data) {
        List<Item> out = new ArrayList<>();
        JSONArray notes = data.optJSONArray("notes");
        if (notes == null) return out;
        List<JSONObject> list = new ArrayList<>();
        for (int i = 0; i < notes.length(); i++) {
            JSONObject n = notes.optJSONObject(i);
            if (n == null || n.optBoolean("trashed", false) || n.optBoolean("archived", false)) continue;
            list.add(n);
        }
        Collections.sort(list, (a, b) -> {
            boolean pa = a.optBoolean("pinned", false), pb = b.optBoolean("pinned", false);
            if (pa != pb) return pa ? -1 : 1;
            return Long.compare(b.optLong("updated", 0), a.optLong("updated", 0));
        });
        for (JSONObject n : list) {
            if (out.size() >= 40) break;
            Item it = new Item();
            it.id = n.optString("id");
            String title = n.optString("title", "").trim();
            String body = n.optString("body", "").trim().replace('\n', ' ');
            JSONArray items = n.optJSONArray("items");
            boolean isList = n.optBoolean("list", false);
            String sub;
            if (isList && items != null) {
                int d = 0;
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < items.length(); j++) {
                    JSONObject x = items.optJSONObject(j);
                    if (x == null) continue;
                    if (x.optBoolean("d", false)) d++;
                    else if (sb.length() < 80) {
                        if (sb.length() > 0) sb.append(", ");
                        sb.append(x.optString("t", ""));
                    }
                }
                sub = d + "/" + items.length() + " · " + sb;
            } else {
                sub = body;
            }
            if (title.isEmpty()) {
                title = sub.isEmpty() ? "Без названия" : sub;
                sub = "";
            }
            if (sub.length() > 90) sub = sub.substring(0, 90) + "…";
            it.title = (n.optBoolean("pinned", false) ? "• " : "") + title;
            it.sub = sub;
            it.color = color(n.optString("color", ""), 0);
            out.add(it);
        }
        return out;
    }
}
